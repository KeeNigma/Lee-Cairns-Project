DispatchRoot='https://cloud.scorm.com/ScormEngineInterface/dispatch/';
ContentURL='https://cloud.scorm.com/EngineWebServices/api/cloud/dispatch/launch?dispatchId=857d191f-37ea-44fb-9a9f-d086d88e7582&launchtoken=U1InuX4OihjZkNFIIrr3kW8LVTAY0WJRAHbSjioH&learnerid=LEARNER_ID&fname=LEARNER_FNAME&lname=LEARNER_LNAME&referringurl=REFERRING_URL&pipeurl=PIPE_URL&redirecturl=REDIRECT_URL&cssurl=CSS_URL_REGISTRATION_ARGUMENT';
DefaultCssUrl='https://app.cloud.scorm.com/sc/css/cloudPlayer/legacy-min.css';
DispatchVersion=2;
TcapiEndpoint='https://cloud.scorm.com/ScormEngineInterface/TCAPI/05L0IGIGI1';
PreLaunchConfigurationURL='https://cloud.scorm.com/EngineWebServices/api/cloud/dispatch/launch/config?dispatchId=857d191f-37ea-44fb-9a9f-d086d88e7582&launchtoken=U1InuX4OihjZkNFIIrr3kW8LVTAY0WJRAHbSjioH';
